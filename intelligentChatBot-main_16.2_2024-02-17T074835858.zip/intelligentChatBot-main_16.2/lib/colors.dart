class AppColor{
  static int primaryColor = 0xff0C8CE9;
}